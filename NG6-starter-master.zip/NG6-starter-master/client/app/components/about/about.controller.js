class AboutController {
  constructor() {
    this.name = 'about';
  }
}

export default AboutController;
