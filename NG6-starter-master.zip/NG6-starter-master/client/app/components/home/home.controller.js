class HomeController {
  constructor() {
    this.name = 'home';
  }
}

export default HomeController;
