class NavbarController {
  constructor() {
    this.name = 'navbar';
  }
}

export default NavbarController;
