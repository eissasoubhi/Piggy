import template from './app.html';
import './app.styl';

let appComponent = {
  template,
  restrict: 'E'
};

export default appComponent;
